﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CurrencyConvert : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        DropDownList1.Items.Clear();
        DropDownList2.Items.Clear();

        String[] currency = { "€ (Euro)", "£ (Ponds)", "$ (US Doller)", "¥ (Japanese yen)",
                                "CHF (Switzerland)","£ (United Kingdom)","kr (Norway)",
                                 "₺ (Turkey)","₪ (Israel)","₦ (Nigeria)"};
        DropDownList1.Items.Add("₹ (Indian rupees)");
        foreach (String item in currency)
        {
            DropDownList2.Items.Add(item);
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        String currency2 = Convert.ToString(DropDownList2.SelectedItem);
        double amount = Convert.ToDouble(TextBox1.Text);
        double value1;
        switch (currency2)
        {
            case "€ (Euro)":
                value1 = 0.011;
                break;
            case "£ (Ponds)":
                value1 = 0.010;
                break;
            case "$ (US Doller)":
                value1 = 0.014;
                break;
            case "¥ (Japanese yen)":
                value1 = 1.41;
                break;
            case "CHF (Switzerland)":
                value1 = 0.012;
                break;
            case "£ (United Kingdom)":
                value1 = 0.010;
                break;
            case "kr (Norway)":
                value1 = 0.12;
                break;
            case "₺ (Turkey)":
                value1 = 0.11;
                break;
            case "₪ (Israel)":
                value1 = 0.044;
                break;
            case "₦ (Nigeria)":
                value1 = 5.12;
                break;
            default:
                value1 = 0;
                Response.Write("Please enter valid option...");
                break;
        }
        double convertedamount = value1 * amount;
        Label4.Text = convertedamount.ToString();
    }
}