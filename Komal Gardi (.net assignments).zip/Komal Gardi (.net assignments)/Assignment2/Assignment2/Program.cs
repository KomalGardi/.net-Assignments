﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    class Program
    {
        static void Main(string[] args)
        {
            ChildClass c = new ChildClass();
            // c.test();
            c.abstdemo();
            Console.ReadLine();
        }
    }
   abstract class ParentClass
    {
        //protected virtual void test()
        //{
        //    Console.WriteLine("This is the method of parent class");
        //}

        protected abstract void abstdemo();
        
    }
 class ChildClass : ParentClass
    {
     public  override void abstdemo()
        {
            Console.WriteLine("Method of Abstract");
            throw new NotImplementedException();
           
        }

        //protected override void test()
        //{
        //    //base.test();
        //    Console.WriteLine("This is the method of child class...");
        //}

        
    }
}
