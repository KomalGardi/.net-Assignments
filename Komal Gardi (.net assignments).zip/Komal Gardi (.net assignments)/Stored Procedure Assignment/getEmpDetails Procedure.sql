create procedure getEmpDetails1 @deptname varchar(20)
as
begin
select id,name,salary from employeeTable inner join departmentTable on departmentno=deptid 
where deptname=@deptname
end