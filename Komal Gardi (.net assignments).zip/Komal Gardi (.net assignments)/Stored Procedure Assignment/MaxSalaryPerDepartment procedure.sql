create procedure MaxSalaryPerDepartment
as
begin
select * from employeeTable
where salary IN(select max(salary) from employeeTable group by departmentno);
end;