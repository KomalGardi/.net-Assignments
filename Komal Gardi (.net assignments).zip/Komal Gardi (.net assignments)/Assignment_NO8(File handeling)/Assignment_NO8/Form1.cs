﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Assignment_NO8
{
    public partial class Form1 : Form
    {
        FileStream f1;
        StreamWriter wrt;
        StreamReader br;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(textBox1.Text);
            String name = textBox2.Text;
            int salary = Convert.ToInt32(textBox3.Text);

            f1 = new FileStream(@"C:\Users\test\Documents\ass1.txt", FileMode.OpenOrCreate, FileAccess.Write);
            if (f1 == null)
            {
                MessageBox.Show("sorry... file not found...");
            }
            else
            {
                wrt = new StreamWriter(f1);
                wrt.Write(id + " " + name + " " + salary);
                MessageBox.Show("inserted successfully...");
            }
            wrt.Close();
            f1.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            f1 = new FileStream(@"C:\Users\test\Documents\ass1.txt", FileMode.Open, FileAccess.Read);
            if (f1 == null)
            {
                MessageBox.Show("sorry... file not found...");
            }
            else
            {
                br = new StreamReader(f1);
                richTextBox1.Text = br.ReadToEnd();
                //MessageBox.Show("inserted successfully...");
            }
            wrt.Close();
            f1.Close();
        }
    }
}
