﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment4
{
    internal class GenericStack
    {
        public void selectChoice(int ch, GenericStack st, Stack<String> stc)
        {
            switch (ch)
            {
                case 1:
                    Console.WriteLine("enter name you want to add...");
                    String name = Console.ReadLine();
                    st.AddElement(stc, name);

                    break;
                case 2:
                    st.getelement(stc);
                    break;
                case 3:
                    st.sortStack(stc);
                    break;
                case 4:
                    st.reverse(stc);
                    break;
                case 5:
                    Console.WriteLine("enter name you want to add...");
                    String name1 = Console.ReadLine();
                    st.searchelement(stc, name1);
                    break;
                case 6:
                    st.Displayelement(stc);
                    break;
                default:
                    Console.WriteLine("Enter valid option...");
                    break;
            }
        }
        public void AddElement(Stack<String> st,String name)
        {
            st.Push(name);

        }
        public void getelement(Stack<String> st)
        {
            Console.WriteLine(st.Pop());
        }
        public void sortStack(Stack<String> st)
        {
            Stack<String> temp1 = new Stack<string>();
            //Stack<String> temp2 = new Stack<String>();

            String [] arr = st.ToArray();
            Array.Sort(arr);
            foreach (var item in arr)
            {
                Console.WriteLine(item);
            }
            Console.ReadLine();
        }
        public void reverse(Stack<String> st)
        {
            st.Reverse();
        }
        public void searchelement(Stack<String> st,String name)
        {
            if(st.Contains(name))
            {
                Console.WriteLine("element found...");
            }
            else
            {
                Console.WriteLine("Element not found...");
            }
        }
        public void Displayelement(Stack<String> st)
        {
            foreach (String item in st)
            {
                Console.WriteLine(item);
            }
        }
    }

    class Employee
    {
        static void Main(string[] args)
        {
            GenericStack st = new GenericStack();
            Stack<String> stc = new Stack<string>();
            stc.Push("Komal");
            stc.Push("ABC");
            stc.Push("cfd");
            stc.Push("htyth");
            stc.Push("fdgdd");
            stc.Push("fdggf");
            Console.WriteLine("Enter your choice");
            Console.WriteLine("1. Push");
            Console.WriteLine("2. Pop");
            Console.WriteLine("3. Sort");
            Console.WriteLine("4. Reverse");
            Console.WriteLine("5. Search");
            Console.WriteLine("6. Display");
            int ch = Convert.ToInt32(Console.ReadLine());
            st.selectChoice(ch,st,stc);
        }
    }

}