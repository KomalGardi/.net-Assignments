﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScientificCalci
{
    public partial class Form1 : Form
    {
        int num1;
        int num2;
        String op;
        public Form1()
        {
            InitializeComponent();
        }
        private void button10_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + (sender as Button).Text;
        }

        // logic for +,
        private void button11_Click(object sender, EventArgs e)
        {
            num1 = Convert.ToInt32(textBox1.Text);
            textBox1.Text = "";
            op = (sender as Button).Text;
        }

        private void button16_Click(object sender, EventArgs e)
        {
            num2 = Convert.ToInt32(textBox1.Text);
            textBox1.Text = "";

            switch (op)
            {
                case "+":
                    textBox1.Text = Convert.ToString(num1 + num2);
                    break;
                case "-":
                    textBox1.Text = Convert.ToString(num1 - num2);
                    break;
                case "*":
                    textBox1.Text = Convert.ToString(num1 * num2);
                    break;
                case "/":
                    textBox1.Text = Convert.ToString(num1 / num2);
                    break;
                case "%":
                    textBox1.Text = Convert.ToString(num1 % num2);
                    break;
                default:
                    MessageBox.Show("Please enter valid option...");
                    break;
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }

        private void button18_Click(object sender, EventArgs e)
        {
                textBox1.Text = textBox1.Text.Remove(textBox1.Text.Length - 1);
        }

        private void button20_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + (sender as Button).Text;
        }

        private void button20_Click_1(object sender, EventArgs e)
        {
            textBox1.Text = Convert.ToString(Math.Sin(Convert.ToDouble(textBox1.Text)));
        }

        private void button22_Click(object sender, EventArgs e)
        {
            textBox1.Text = Convert.ToString(Math.Cos(Convert.ToDouble(textBox1.Text)));
        }

        private void button23_Click(object sender, EventArgs e)
        {
            textBox1.Text = Convert.ToString(Math.Tan(Convert.ToDouble(textBox1.Text)));
        }

        private void button24_Click(object sender, EventArgs e)
        {
            textBox1.Text = "3.141592654";
        }
    }
}
